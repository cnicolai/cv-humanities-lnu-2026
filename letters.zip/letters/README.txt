Read a letter page: the letters
==============================

Three pages from the letters between George Stephens, in Copenhagen, and his son Joseph, in
Bombay, in the Huseby Archives (Husebyarkivet), Linnaeus University. Start with letter 1.

  1-joseph-1868-03-27   Joseph Stephens to his father George, 27 March 1868, page D (710 characters)
  2-joseph-1869-01-29   Joseph Stephens to his father George, 29 January 1869, page D (806 characters)
  3-george-1868-07-07   George Stephens to his son Joseph, Copenhagen, 7 July 1868, page 1a (1137 characters)

Each .jpg is the page as scanned. Give it to the model in LM Studio.
Each .txt is the page as a person transcribed it, one line per written line. Paste it into
cer.html as the reference.

cer.html counts the errors. Open it by double-clicking it; it opens in your web browser and
works offline. Paste the transcription on the left and the model's text on the right.

The letters are public domain (Public Domain Mark on Alvin, alvin-portal.org). The
transcriptions were made for the master's thesis "Reading the Crossed Page: Making
Cross-Written Letters Accessible in Content and Form" (Christoph Nicolai, Linnaeus
University, 2026).
